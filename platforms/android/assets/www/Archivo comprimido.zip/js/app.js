(function () {

    /* ---------------------------------- Local Variables ---------------------------------- */
    var service = new envioservice();
        service.initialize().done(function () {
        console.log("Service initialized");
    });

    /* --------------------------------- Event Registration -------------------------------- */
    $('.search-key').on('keyup', findByName);
    document.addEventListener('deviceready', function () {
        FastClick.attach(document.body); //Librería que nos permite saltarnos el Delay de 300ms al interactuar con la app
        if (navigator.notification) { 
          window.alert = function (message) {
              navigator.notification.alert(
                  message,    
                  null,       
                  "Envia UOC",
                  'OK'        
              );
          };
        }
    }, false);
    /* ---------------------------------- Local Functions ---------------------------------- */
    //Función de Búsqueda.
    function findByName() {
        service.findByName($('.search-key').val()).done(function (envios) {
            var l = envios.length;
            var e;
            $('.envios-list').empty();
            for (var i = 0; i < l; i++) {
                e = envios[i];
                $('.envios-list').append('<li><a href="#envios/' + e.codigoTrack + '">' + e.direccionEnvio'</a></li>');
            }
        });
    }

}());