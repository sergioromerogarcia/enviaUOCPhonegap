var Usuarios = function() {

    this.initialize = function() {
        // No Initialization required
        var deferred = $.Deferred();
        deferred.resolve();
        return deferred.promise();
    }

    this.findById = function(id) {
        var deferred = $.Deferred();
        var envio = null;
        var l = usuarios.length;
        for (var i=0; i < l; i++) {
            if (usuarios[i].id === id) {
                envio = usuarios[i];
                break;
            }
        }
        deferred.resolve(envio);
        return deferred.promise();
    }
    //Búsqueda de Usuarios según el código de Usuario
    this.findByName = function(searchKey) {
        var deferred = $.Deferred();
        var results = usuarios.filter(function(element) {
            var stringBusqueda = element.user_id;
            return stringBusqueda.toLowerCase().indexOf(searchKey.toLowerCase()) > -1;
        });
        deferred.resolve(results);
        return deferred.promise();
    }
    //Array de usuarios de ejemplo
    var usuarios = [
        {"user_id": 1, "nombreUsuario": "user1", "passwordUsuario": "passuser1", "emailUsuario": "user1@prueba.es"},
        {"user_id": 2, "nombreUsuario": "user2", "passwordUsuario": "passuser2", "emailUsuario": "user2@prueba.es"},
        {"user_id": 3, "nombreUsuario": "user3", "passwordUsuario": "passuser3", "emailUsuario": "user3@prueba.es"},
        {"user_id": 4, "nombreUsuario": "user4", "passwordUsuario": "passuser4", "emailUsuario": "user4@prueba.es"}
    ];

}