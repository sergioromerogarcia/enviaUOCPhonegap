var Envios = function() {

    this.initialize = function() {
        // No Initialization required
        var deferred = $.Deferred();
        deferred.resolve();
        return deferred.promise();
    }

    this.findById = function(id) {
        var deferred = $.Deferred();
        var envio = null;
        var l = envios.length;
        for (var i=0; i < l; i++) {
            if (envios[i].id === id) {
                envio = envios[i];
                break;
            }
        }
        deferred.resolve(envio);
        return deferred.promise();
    }
    //Búsqueda de Envíos según el código de Usuario
    this.findByName = function(searchKey) {
        var deferred = $.Deferred();
        var results = envios.filter(function(element) {
            var stringBusqueda = element.codigoTrack;
            return stringBusqueda.toLowerCase().indexOf(searchKey.toLowerCase()) > -1;
        });
        deferred.resolve(results);
        return deferred.promise();
    }
    //Array de envíos de ejemplo
    var envios = [
        {"id": 1, "codigoTrack": "1111", "direccionEnvio": "Direccion de envio 1", "user_id": 1},
        {"id": 2, "codigoTrack": "2222", "direccionEnvio": "Direccion de envio 2", "user_id": 1},
        {"id": 3, "codigoTrack": "3333", "direccionEnvio": "Direccion de envio 3", "user_id": 2},
        {"id": 4, "codigoTrack": "4444", "direccionEnvio": "Direccion de envio 4", "user_id": 2},
        {"id": 5, "codigoTrack": "5555", "direccionEnvio": "Direccion de envio 5", "user_id": 3},
        {"id": 6, "codigoTrack": "6666", "direccionEnvio": "Direccion de envio 6", "user_id": 3},
        {"id": 7, "codigoTrack": "7777", "direccionEnvio": "Direccion de envio 7", "user_id": 4},
        {"id": 8, "codigoTrack": "8888", "direccionEnvio": "Direccion de envio 8", "user_id": 4}                         
    ];

}